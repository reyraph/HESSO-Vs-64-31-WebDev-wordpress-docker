# Help Panel

The "Help" panel in the GraphiQL IDE provides users with quick access to links to helpful resources such as articles on the WPGraphQL website and access to join the WPGraphQL Slack community.

This panel is built as if it were a 3rd party plugin, leveraging APIs provided by the WPGraphQL API.

![Screenshot of the Help panel](./img/readme-img.png)
