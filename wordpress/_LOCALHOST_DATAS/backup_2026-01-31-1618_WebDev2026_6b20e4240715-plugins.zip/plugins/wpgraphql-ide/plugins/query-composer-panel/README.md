# Query Composer Panel

Registers a new Activity Bar Panel with the IDE.
